(() => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.site-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(open));
      document.body.classList.toggle('menu-open', open);
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('menu-open');
    }));
    window.addEventListener('resize', () => {
      if (window.innerWidth > 680) {
        nav.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('menu-open');
      }
    });
  }
  document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());
  const form = document.querySelector('#contact-form');
  if (form) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const data = new FormData(form);
      const email = form.dataset.email || 'YOUR_EMAIL@example.com';
      if (email.includes('YOUR_EMAIL')) {
        const status = form.querySelector('.form-status');
        status.textContent = 'Form layout is ready. Set your receiving email in contact.html before using this form.';
        return;
      }
      const subject = encodeURIComponent(`Website enquiry: ${data.get('subject') || 'New message'}`);
      const body = encodeURIComponent(`Name: ${data.get('name')}\nEmail: ${data.get('email')}\nSubject: ${data.get('subject')}\n\nMessage:\n${data.get('message')}`);
      window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
      form.querySelector('.form-status').textContent = 'Your email application should open with the enquiry prepared.';
    });
  }
})();
